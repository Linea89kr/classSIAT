package com.example.jsp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jsp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Jsp1Application.class, args);
	}

}
